
#!/bin/bash
echo "Hello, World!"

name="HR"
echo "Hello, $name"

num=10 

if [ "$num" -gt 5 ]; then
  echo "number is greater than 5"
fi

for i in 1 2 3
do 
echo "Number: $i"
done
